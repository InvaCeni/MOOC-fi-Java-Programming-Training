
public class AdvancedAstrology {

    public static void main(String[] args) {
        printSpaces(3);
        printStars(5);

        printTriangle(4);

        printChristmasTree(4);
        printChristmasTree(10);
    }

    public static void printSpaces(int number) {
        for (int i = 0; i < number; i++) {
            System.out.print(" ");
        }
    }

    public static void printStars(int number) {
        for (int i = 0; i < number; i++) {
            System.out.print("*");
        } System.out.println();
    }
    public static void printTriangle(int size) {
        for (int i = 1; i <= size; i++){
            printSpaces(size -1);
            printStars(size);
            System.out.println();
        }

    }

    public static void printChristmasTree(int height) {
        for (int i = 1; i <= height; i++) {
            printSpaces(height -1);
            printStars(i * 2- 1);
            System.out.println();
        }
        printSpaces(height - 1);
        printStars(3);
        System.out.println();
        printSpaces(height - 1);
        printStars(3);
        System.out.println();
    }
}